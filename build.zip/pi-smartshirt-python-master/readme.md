sudo python /home/pi/server_python/server.py 8 8 1 5x7 0

## Setup

Start the server on the raspberry pi using `sudo python server.py`.

This will set the number of LEDs to a 8x8 matrix.
If you want to change this, you can pass x and y as arguments.
Example: `sudo python server.py 5 5`

If you want to configure the server for autostart, use the `/etc/rc.local` file and put there a line like `python <path to server.py>`.

## Web App

To update the web app, build the latest version of [smartshirt repo](https://github.com/penguin-digital/smartshirt).

To include it:
Build the app: `npm run build`
Move the HTML file to `/templates` folder.
Move the other static assets into the `/static` folder.


## Sensor Libraries:

https://learn.adafruit.com/mcp9808-temperature-sensor-python-library/software (Installation)

https://github.com/adafruit/Adafruit_Python_MCP9808

https://github.com/adafruit/Adafruit_Python_TCS34725

## Code Style

This project uses prettier (https://prettier.io/) for JavaScript Code.
